#ifndef POWER_H
#define POWER_H
extern double power(double base, int exponent);
#endif
